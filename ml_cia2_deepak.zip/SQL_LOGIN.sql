drop database login;
CREATE database login; 
USE login;

CREATE TABLE details(
		username varchar (20),
        password varchar (20));
        
INSERT into details values (
	'DEEPAK_T','123');
SELECT *from details