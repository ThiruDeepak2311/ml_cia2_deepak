import pickle as pkl 
import numpy as np
import mysql.connector as sql

from flask import Flask, render_template, request, url_for, redirect
app = Flask(__name__)

@app.route('/')
def home():
    return render_template("login.html")

@app.route("/login",methods=["GET","POST"])
def login():
    con=sql.connect(user='root', password='Deepak_2311',host='localhost',database='login')
    cur=con.cursor()

    username = request.form['username']
    password = request.form['password']
    cur.execute('select * from details')
    t=cur.fetchone()
    # Check if the username exists and the password matches
    if username ==t[0] and password==t[1]:
        return render_template("index.html")

    else:
        return render_template("login.html")
if __name__ == '__main__':
    app.run()
    
@app.route("/recommendations", methods=['GET'])
def recommendations():
    user_id = int(request.args.get('user_id'))
    n_recommendations = int(request.args.get('n_recommendations', 10))
    
    # Load the trained recommender model
    with open('recommender_model.pkl', 'rb') as f:
        model = pkl.load(f)
    
    # Load the user-item matrix and mappers
    with open('user_item_matrix.pkl', 'rb') as f:
        X, user_mapper, movie_mapper, user_inv_mapper, movie_inv_mapper = pkl.load(f)
    
    # Get the index of the user in the matrix
    user_index = user_mapper[user_id]
    
    # Get the scores for all movies for the user
    user_scores = model.predict(user_index, np.arange(X.shape[0]))
    
    # Get the indices of the top n_recommendations movies
    top_indices = np.argsort(-user_scores)[:n_recommendations]
    
    # Convert the movie indices back to movieIds and get the movie titles
    top_movies = [movie_inv_mapper[i] for i in top_indices]
    top_titles = [movie_mapper[m] for m in top_movies]
    
    # Render the template with the movie recommendations
    return render_template('recommendations.html', user_id=user_id, recommendations=top_titles)